#include <stdio.h>

int main(void) {
 float answer;
  SIN_TIPO answer;
  SIN_TIPO answercero;
	SIN_TIPO answerone;
	/* Instrucciones */
	printf("Bienvenido al sistema que te ayuda a solucionar problemas con tu microondas\n");
	printf("Responde Si presionando el n?mero 0 en tu teclado y 1 para un No\n");
	printf("?Esta conectado el microondas?\n");
	scanf("%s",answer);
	/* Si la respuesta es si, que el usuario presione 0, de lo contrario, que presione 1. */
	if (answer==0) {
		/* ***- L�gica del ejercicio -*** */
		if (answer==0) {
			printf("?Encendio la pantalla del microondas?\n");
			scanf("%s",answerone);
			/* Aqu� el usuario si confirma que si, tiene que dar clic en el 0. */
			if (answer==0) {
				/* Vamos a mostrar el mensaje que corresponde a la respuesta dada. */
				printf("Remplazar el microondas, por favor\n");
			} else {
				printf("Comprar un microondas nuevo, por favor\n");
			}
		} else {
			printf("Conectelo, por favor.\n");
		}
	}
	if (answer==1) {
		/* ***- L�gica del ejercicio -*** */
		if (answer==0) {
			printf("?Encendio la pantalla del microondas?\n");
			scanf("%s",answercero);
			/* Aqu� el usuario si confirma que si, tiene que dar clic en el 0. */
			if (answer==1) {
				/* Vamos a mostrar el mensaje que corresponde a la respuesta dada. */
				printf("Remplazar el microondas, por favor\n");
			} else {
				printf("Comprar un microondas nuevo, por favor\n");
			}
		} else {
			printf("Conectelo, por favor.\n");
		}
	}
	/* Se evalua la tecla presionada por el usuario y si no es: 0 o 1, devuelve un mensaje de error */
	if (answer!=0 || answer!=1) {
		printf("Respuesta no v�lida :D\n");
	}
	return 0;
}